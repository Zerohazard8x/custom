// ==UserScript==
// @name            Privacy
// @description     Prevents websites from taking information about activities
// @author          Zerohazard8x + GPT
// @include         *://*/*
// @run-at          document-end
// @grant           none
// ==/UserScript==

const preventEvent = function (event) {
  event.preventDefault();
  event.returnValue = false;
};

const eventsToPrevent = [
  "beforeunload",
  "unload",
  "hashchange",
  "popstate",
];

// Prevent events on window object
eventsToPrevent.forEach(function (event) {
  window.addEventListener(event, preventEvent, true);
});

// Remove third-party event listeners on document object
const oldAddEventListener = EventTarget.prototype.addEventListener;
const oldRemoveEventListener = EventTarget.prototype.removeEventListener;

EventTarget.prototype.addEventListener = function (type, listener, options) {
  if (this === document && listener.toString().includes("http")) {
    return;
  }
  oldAddEventListener.call(this, type, listener, options);
};

EventTarget.prototype.removeEventListener = function (type, listener, options) {
  if (this === document && listener.toString().includes("http")) {
    return;
  }
  oldRemoveEventListener.call(this, type, listener, options);
};