// ==UserScript==
// @name            Privacy
// @description     Prevents websites from taking information about activities
// @author          Zerohazard8x + GPT
// @match           *://*/*
// @run-at          document-end
// @grant           none
// @exclude         *bing.com*
// @exclude         *discord.com*
// @exclude         *youtube.com*
// @exclude         *nvidia.com*
// @exclude         *lazada.com.ph*
// @exclude         *alicdn.com*
// @exclude         *live.com*
// @exclude         *tweetdeck.twitter.com*
// @exclude         *messenger.com*
// @exclude         *reddit.com*
// ==/UserScript==

const preventEvent = function (event) {
  event.stopPropagation();
  event.stopImmediatePropagation();
};

const eventsToPrevent = [
  // window.onload -> "onload"
  "onload",
  "onclick",
  "onkeypress",
  "ontouchstart",
  "onmousemove",
  "onmousedown",
  "onbeforeunload",
  "onunload",
  "onhashchange",
  "onpopstate",
  "oncontextmenu",
  "ondragstart",
  "ondragend",
  "ondragover",
  "ondragenter",
  "ondragleave",
  "ondrop",
];

// Prevent events on window and document objects
for (const event of eventsToPrevent) {
  window[event] = preventEvent;
  document[event] = preventEvent;
}

// Remove all event listeners on document object
const oldAddEventListener = EventTarget.prototype.addEventListener;
const oldRemoveEventListener = EventTarget.prototype.removeEventListener;
const listeners = new Map();

EventTarget.prototype.addEventListener = function (type, listener, options) {
  if (this === document) {
    listeners.set(listener, options);
  }
  oldAddEventListener.call(this, type, listener, options);
};

EventTarget.prototype.removeEventListener = function (type, listener) {
  if (this === document) {
    listeners.delete(listener);
  }
  oldRemoveEventListener.call(this, type, listener);
};

function removeAllDocumentListeners() {
  for (const [listener, options] of listeners) {
    document.removeEventListener(listener, options);
  }
  listeners.clear();
}
removeAllDocumentListeners();