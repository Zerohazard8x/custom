// ==UserScript==
// @name            Privacy
// @description     Prevents websites from taking information about activities
// @match           *://*/*
// @run-at          document-start
// @grant           none
// ==/UserScript==

const preventEvent = function (event) {
  event.stopPropagation();
  event.stopImmediatePropagation();
};

// Override the default addEventListener and removeEventListener methods
const originalAddEventListener = EventTarget.prototype.addEventListener;
const originalRemoveEventListener = EventTarget.prototype.removeEventListener;

EventTarget.prototype.addEventListener = function (type, listener, options) {
  // If the event type is one of the following, prevent it from being registered
  if (["beforeunload", "unload", "hashchange", "popstate", "visibilitychange"].includes(type)) {
    return;
  }
  // Otherwise, call the original method
  originalAddEventListener.call(this, type, listener, options);
};

EventTarget.prototype.removeEventListener = function (type, listener) {
  // If the event type is one of the following, prevent it from being removed
  if (["beforeunload", "unload", "hashchange", "popstate", "visibilitychange"].includes(type)) {
    return;
  }
  // Otherwise, call the original method
  originalRemoveEventListener.call(this, type, listener);
};