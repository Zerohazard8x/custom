// ==UserScript==
// @name            Privacy
// @description     Prevents websites from taking information about activities
// @author          Zerohazard8x + GPT
// @match           *://*/*
// @run-at          document-end
// @grant           none
// @exclude         *bing.com*
// ==/UserScript==

const preventEvent = function (event) {
  event.stopPropagation();
  event.stopImmediatePropagation();
};

const eventsToPrevent = [
  "load",
  "click",
  "keypress",
  "touchstart",
  "mousemove",
  "mousedown",
  "beforeunload",
  "unload",
  "hashchange",
  "popstate",
  "contextmenu",
  "dragstart",
  "dragend",
  "dragover",
  "dragenter",
  "dragleave",
  "drop",
];

// Prevent events on window and document objects
eventsToPrevent.forEach(function (event) {
  window.addEventListener(event, preventEvent, true);
  document.addEventListener(event, preventEvent, true);
});

// Remove all event listeners on document object
const oldAddEventListener = EventTarget.prototype.addEventListener;
const oldRemoveEventListener = EventTarget.prototype.removeEventListener;

EventTarget.prototype.addEventListener = function (type, listener, options) {
  if (this === document) {
    return;
  }
  oldAddEventListener.call(this, type, listener, options);
};

EventTarget.prototype.removeEventListener = function (type, listener, options) {
  if (this === document) {
    return;
  }
  oldRemoveEventListener.call(this, type, listener, options);
};
