// ==UserScript==
// @name         TweetDeck Beta Switcher
// @namespace    https://github.com/assistant
// @version      1.0
// @description  Switch to the beta version of TweetDeck
// @author       Zerohazard8x
// @match        https://tweetdeck.twitter.com/
// ==/UserScript==

document.cookie = "tweetdeck_version=beta"